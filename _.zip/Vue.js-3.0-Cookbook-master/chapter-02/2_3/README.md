# 2.3 - Creating your first TypeScript class

## Project setup
```
yarn install
```

### Compiles for development
```
tsc ./Dog.ts
```