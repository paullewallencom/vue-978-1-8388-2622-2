# 2.1 - Creating a TypeScript Project

## Project setup
```
yarn install
```

### Compiles for development
```
tsc ./index.ts
```