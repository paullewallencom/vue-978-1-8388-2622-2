# 1.4 - Creating components with attribute inheritance
