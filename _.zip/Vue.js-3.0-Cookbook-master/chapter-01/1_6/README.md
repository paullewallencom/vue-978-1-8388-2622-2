# 1.6 - Creating a component using the composition API
