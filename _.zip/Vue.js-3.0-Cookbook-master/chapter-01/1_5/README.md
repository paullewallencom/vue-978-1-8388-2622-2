# 1.5 - Using the reactivity and observable API outside the scope of Vue
