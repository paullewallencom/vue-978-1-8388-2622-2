export default {
  users: [
    {
      name: 'Heitor Ramon Ribeiro',
      email: 'heitor@example.com',
      birthday: '1988-06-15',
      country: 'Brazil',
      phone: '+55 00 0000 0000',
      active: true,
    },
  ],
};
