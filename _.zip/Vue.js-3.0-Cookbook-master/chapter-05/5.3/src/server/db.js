export default {
  users: [
    {
      name: 'Heitor Ramon Ribeiro',
      email: 'heitor@example.com',
      age: 31,
      country: 'Brazil',
      active: true,
    },
  ],
};
