export const getFrom = key => ({ db }) => db[key];

export default {
  getFrom,
};
